package pepse.util;

import java.awt.*;

public class ColorSupplier {

    /**
     * Returns a color similar to baseColor, with a default delta.
     * @param baseColor A color that we wish to approximate.
     * @return A color similar to baseColor.
     */
    public static Color approximateColor( Color baseColor){


    } // end of approximateColor

    /**
     * Returns a color similar to baseColor, with a difference of at most colorDelta.
     * @param baseColor A color that we wish to approximate.
     * @param colorDelta The maximal difference (per channel) between the sampled color and the base color.
     * @return A color similar to baseColor.
     */
    public static Color approximateColor( Color baseColor, int colorDelta){


    } // end of approximateColor


} // end of color supplier class
