package pepse;

import danogl.GameManager;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;

public class PepseGameManager extends GameManager {

    public PepseGameManager() {
        //empty constructor
    } // end of constructor


    /**
     * The method will be called once when a GameGUIComponent is created, and again after every invocation of windowController.resetGame().
     * @param imageReader  Contains a single method: readImage, which reads an image from disk. See its documentation for help.
     * @param soundReader Contains a single method: readSound, which reads a wav file from disk. See its documentation for help.
     * @param inputListener r help.
     * inputListener - Contains a single method: isKeyPressed, which returns whether a given key is currently pressed by the user or not. See its documentation.
     * @param windowController Contains an array of helpful, self explanatory methods concerning the window.
     */
    public void initializeGame(ImageReader imageReader , SoundReader soundReader, UserInputListener inputListener, WindowController windowController){

    } // end of initializeGame

    /**
     * Runs the entire simulation.
     * @param args This argument should not be used.
     */
    public static void main(String[] args){


    } // end of main


} // end of PepseGameManager
