package pepse.world;

import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

public class Block {
    public static final int SIZE = 5; // need to check what i need to define it
    private Vector2 topLeftCorner;
    private Renderable renderable;

    /**
     * Constructs a block
     * @param topLeftCorner
     * @param renderable
     */
    public Block(Vector2 topLeftCorner, Renderable renderable) {
         // empty constructor
        this.topLeftCorner = topLeftCorner;
        this.renderable = renderable;
    } // end of constructor


} // end of class Block
