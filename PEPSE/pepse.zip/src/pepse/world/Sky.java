package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.util.Vector2;

public class Sky {
    public Sky() {
      //empty constructor
    } // end of constructor

    /**
     * A method that creates a sky game object.
     * @param gameObjects The collection of all participating game objects.
     * @param windowDimensions The number of the layer to which the created game object should be added.
     * @param skyLayer The number of the layer to which the created sky should be added.
     * @return A new game object representing the sky.
     */
    public static GameObject create(GameObjectCollection gameObjects, Vector2 windowDimensions, int skyLayer){

    } // end of method create

} // end of class Sky
